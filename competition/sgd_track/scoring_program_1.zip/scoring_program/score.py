import argparse
import os
# os.environ['OPENBLAS_NUM_THREADS'] = '1'
print("os.environ:", os.environ)
import time
import gym
# import numpy as np
import warnings

# Parts of the code inspired by the AutoML3 competition
from sys import argv, path
from os import getcwd
from os.path import join
verbose = True

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="The experiment runner for the DAC4RL track."
    )
    parser.add_argument(
        "-t",
        "--competition-track", 
        choices=['dac4sgd', 'dac4rl'], 
        help="DAC4SGD or DAC4RL", 
        default="dac4rl",
    )
    parser.add_argument(
        "-i",
        "--input-dir",
        type=str,
        default="",
        help="",
    )
    parser.add_argument(
        "-o",
        "--output-dir",
        type=str,
        default="",
        help="",
    )

    root_dir = getcwd()
    print("Working directory:", root_dir)
    args, unknown = parser.parse_known_args()
    # TODO: Should be cmd arguments

    # ingestion_dir = os.path.abspath(args.ingestion_dir)
    # input_dir = os.path.abspath(args.input_dir)
    output_dir = os.path.abspath(args.output_dir)
    # hidden_dir = os.path.abspath(args.hidden_dir)
    # shared_dir = os.path.abspath(args.shared_dir)
    # submission_dir = os.path.abspath(args.submission_dir)
    if verbose:
        # print("Using ingestion_dir: " + ingestion_dir)
        # print("Using input_dir: " + input_dir)
        print("Using output_dir: " + output_dir)
        # print("Using hidden_dir: " + hidden_dir)
        # print("Using shared_dir: " + shared_dir)
        # print("Using submission_dir: " + submission_dir)

    # path.append(args.submission_dir)
    # print("path:", path)


    # if args['env_name'] == "sgd-v0":
    #     import sgd_env
    # else:  # "== 'dac4carl-v0'"
    #     import rlenv

    # env = gym.make(args["env_name"])

    # total_rewards = run_experiment_draft(policy, env, **args)

    # print("total_rewards:", total_rewards)
    # np.savetxt("scores_1.txt", total_rewards, delimiter=",")

    if not os.path.exists(args.output_dir):
        print("Path not found:", args.output_dir)
        os.makedirs(args.output_dir)

    # Write scores.txt
    # fout = open(args.output_dir + '/scores.txt', 'a')
    # # for rew in total_rewards:
    # fout.write("DLSCORES: " + str(0.0) + '\n')
    # fout.write("RLSCORES: " + str(0.0) + '\n')
    # fout.close()


    if os.path.exists(args.output_dir):
        print("Output directory contents:")
        os.system("ls -lR " + args.output_dir)

    if os.path.exists(args.input_dir):
        # print("Input directory exists.")
        os.system("cp " + args.input_dir + "/res/scores.txt " + args.output_dir)
    else:
        print("No results from ingestion!")

    with open(args.output_dir + '/scores.txt', 'r') as fh:
        print(fh.readlines())

    # with open(args.input_dir + '/scores.txt', 'r') as fh:
    #     print(fh.readlines())

